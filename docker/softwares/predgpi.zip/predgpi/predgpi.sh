#!/bin/bash
export PREDGPI_HOME='/bioinformatic/predgpi'
TEMPFILE=$(mktemp)
#echo $TEMPFILE
python3 $PREDGPI_HOME/predgpi.py -f $1 -o $TEMPFILE
cat $TEMPFILE
rm -f $TEMPFILE

