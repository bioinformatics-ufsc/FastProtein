#!/bin/bash
export PREDGPI_HOME='/bioinformatic/predgpi'
python3 $PREDGPI_HOME/predgpi.py -f $1 -o $2
